package dev.fujioka.java.avancado.web;


class HelloWorldResourceTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void primeiroEndPointGetHello() {
    }

    @org.junit.jupiter.api.Test
    void primeiroEndPointDeleteHello() {
    }

    @org.junit.jupiter.api.Test
    void primeiroEndPointPutHello() {
    }

    @org.junit.jupiter.api.Test
    void primeiroEndPointPostHello() {
    }
}